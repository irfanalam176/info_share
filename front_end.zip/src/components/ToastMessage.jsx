import React from 'react'
import { Toast } from 'react-bootstrap'
export default function ToastMessage({props}) {
  return (
    <Toast show={props.show} onClose={props.closeToast} position="top-end" style={
        {
            background:"red",
            color:"white"
        }
    }>
    <Toast.Header>
      <img src="holder.js/20x20?text=%20" className="rounded me-2" alt="" />
    </Toast.Header>
    <Toast.Body>{props.message}</Toast.Body>
  </Toast>
  )
}
