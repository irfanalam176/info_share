import React from "react";
import { Link } from "react-router-dom";
export default function BlogCard({props}) {
  return (
    <Link to={`/readBlog/blogPage?q=${props.blog_id}&v=${props.user_id}`} className="d-block my-2" data-aos="fade-up">
      <div className="blogCard">
        <img
          src={props.thumbnail}
          alt=""
        />
        <div>
          <h1>{props.title}</h1>
          <p>
            {props.description}
          </p>
        </div>
      </div>
    </Link>
  );
}
