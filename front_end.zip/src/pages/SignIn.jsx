import React,{  useContext,useEffect,useState} from 'react'
import host from "../host/host"
import stateContext from '../context/stateContext'
import { Link,useNavigate } from 'react-router-dom'
import ToastMessage from '../components/ToastMessage';
export default function SignIn() {
  const navigate=useNavigate()
  let{isLogin,setIsLogin}=useContext(stateContext)
  useEffect(()=>{
    const token=localStorage.getItem("token")
    if(token!=null){
      if(token.length>0){
        navigate("/")
      }
     }
  },[])
  let[isSigning,setIsSigning]=useState(false)
  const[error,setError]=useState("")
  const[showToast,setShowToast]=useState(false)
  const [formData, setFormData] = useState({
    userEmail: '',
    userPassword: '',
  });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const userInfo = {
    userEmail: formData.userEmail,
    userPassword: formData.userPassword
};
const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

function isValidEmail(email) {
  return emailRegex.test(email);
}

  async function signIn(e){
    e.preventDefault();
    setIsSigning(true)
    if(userInfo.userEmail!=""&&userInfo.userPassword.length>=8&&isValidEmail(userInfo.userEmail))
    {
      try{
        await fetch(`${host}signIn`,{
          method:"POST",
          headers:{
            "content-type":"application/json"
          },
          body:JSON.stringify(userInfo)
        }).then((response)=>response.json()).then((response)=>{
          if(response.message==true){
            tokenSetter(response)
            setIsSigning(false)
          }else if(response.message==false){
            setIsSigning(false)
            setError("User Not Found")
            setShowToast(!showToast)
          }
        })
      }catch(e){
        setIsSigning(false)
        setError("Server Error Occured..")
        setShowToast(!showToast)
      }
    }else{
      setIsSigning(false)
      setError("Invalid Information..")
      setShowToast(!showToast)
    }
  }
  
  function tokenSetter(response){
   if(response.message==true){
    localStorage.setItem("token",JSON.stringify(response.token))
    localStorage.setItem("userId",JSON.stringify(response.userId))
    setIsLogin(true)
    navigate("/writeBlog")
   }
  }
  return (
  <>
  <ToastMessage props={{show:showToast,message:error,closeToast:()=>setShowToast(!showToast)}}/>
   <div className="signWrapper" data-aos="fade-down">
     <div className='signPage'>
     {isSigning&&
      <div className='loaderContainer'>
        <div className="loader"></div>
      </div>
      }
        <h1 className="mainHeading">Sign In</h1>
        <input type="email" name='userEmail' placeholder='jhonDoe@yahoo.com' onChange={handleInputChange}/>
        <input type="password" name='userPassword' placeholder='Enter Your Password (minimum 8 characters)' minLength={8} onChange={handleInputChange}/>
        <div className="text-end  w-100">
        <Link to={"/signUp"}>Create New Account?</Link>
        </div>
        <button className='mainBtn' onClick={signIn}>Sign In</button>
    </div>
   </div>
  </>
   
  )
}
