import React from 'react'
import {Row,Col} from "react-bootstrap"
export default function Home() {
    const homeImage="https://images.pexels.com/photos/1228517/pexels-photo-1228517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  return (
    <div className='home'>
       <Row>
            <Col lg={6} className='my-auto px-lg-5'>
                <h1 className="welcomeTitle">Welcome to InfShare - Your Gateway to Information Exchange</h1>
                <p className="welcomeText">
                Welcome to InfShare, your ultimate destination for seamless information exchange and knowledge sharing. In a world where information is key, InfShare stands as a beacon, offering a dynamic platform where ideas, insights, and expertise converge. Whether you are a passionate learner, a seasoned professional, or an avid knowledge seeker, InfShare is designed to cater to your intellectual cravings. Our platform is more than just a repository of information; it's a vibrant community where minds meet, collaborate, and grow together. Explore a vast array of topics, engage in thought-provoking discussions, and share your unique perspective with a global audience. At InfShare, we believe in the power of knowledge to transform lives, and we invite you to be a part of this journey. Join us in building a community where information knows no boundaries and is freely shared for the betterment of all. InfShare - Unleashing the power of shared knowledge.
                </p>
            </Col>
            <Col lg={6} className='imageContainer'>
                <img src={homeImage} alt="" />
            </Col>
        </Row>
    
    </div>
  )
}
