import React, { useEffect,useState,useContext } from 'react'
import stateContext from '../context/stateContext'
import BlogCard from '../components/BlogCard'
import host from "../host/host"
import Shimmer from '../features/Shimmer'
import { Link } from 'react-router-dom'
export default function ReadBlog() {
  let{setSearch}=useContext(stateContext)
  const emptyArray=[1,2,3,4,5]
  let[blogs,setBlogs]=useState([])
  useEffect(()=>{
    getData()
  },[])
  async function getData(){
    try{
      await fetch(`${host}blogCard`).then((response)=>response.json()).then((response)=>{
        setBlogs(response.data)
      })
    }catch(error){
      console.log(error);
    }
  }
  return (
      <div className='wrapper'>
        <div className="searchBlog">
            <input type="text" name='searchBlog' placeholder='Search Blog' onChange={(e)=>setSearch(e.target.value)}/>
            <Link className='findBtn' to={"/readBlog/search"}>Find</Link>
        </div>
        {
         blogs.length>0? blogs.map((index,key)=>{
            return <BlogCard props={index} key={key}/>
          }):emptyArray.map((index,key)=>{return <Shimmer key={key}/>})
        }
      
    </div>
  )
}
