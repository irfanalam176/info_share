import React, { useEffect,useState,useContext } from 'react'
import stateContext from '../context/stateContext'
import BlogCard from '../components/BlogCard'
import host from "../host/host"
import Shimmer from '../features/Shimmer'
import back from "../assets/back.png"
import { useNavigate } from 'react-router-dom'
export default function Search() {
  
    const navigate=useNavigate()
  const emptyArray=[1,2,3,4,5]
  let[blogs,setBlogs]=useState([])
  let{search}=useContext(stateContext)
  useEffect(()=>{
      getData()
    },[])
    async function getData(){
    try{
      await fetch(`${host}searchBlog?v=${search}`).then((response)=>response.json()).then((response)=>{
        setBlogs(response.data)
      })
    }catch(error){
      console.log(error);
    }
  }
  return (
      <div className='wrapper'>
        <div className="searchBlog justify-content-start ps-3">
            <span className='searchBtn'
            onClick={()=>navigate("/readBlog")}
            ><img src={back} alt="" /></span>
        </div>
        {
         blogs.length>0? blogs.map((index,key)=>{
            return <BlogCard props={index} key={key}/>
          }):emptyArray.map((index,key)=>{return <Shimmer key={key}/>})
        }
      
    </div>
  )
}
