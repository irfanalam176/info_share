import React, { useEffect,useState } from 'react'
import { useLocation } from 'react-router-dom'
import host from "../host/host"
export default function BlogPage() {
const[html,setHtml]=useState("")
const[writer,setWriter]=useState("")

const location = useLocation();
const queryParams = new URLSearchParams(location.search);
const q = queryParams.get('q');
const v = queryParams.get('v');
useEffect(()=>{
    getBlog()
},[])

async function getBlog(){
    await fetch(`${host}readBlog/?q=${q}&v=${v}`).then((response)=>response.json()).then((response)=>{
        setHtml(response.result.html)
        setWriter(response.result.userName)
    })
}
  return (
    <div className='wrapper'>
        <span className='blogWriter'>Blog Writer: {writer}</span>
        <div  dangerouslySetInnerHTML={{__html:html}} data-aos="fade-up">
        
        </div>
    </div>
  )
}
