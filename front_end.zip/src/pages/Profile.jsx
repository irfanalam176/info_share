import React, { useEffect,useState } from 'react'
import host from "../host/host"
import { useNavigate } from 'react-router-dom'
import BlogCard from '../components/BlogCard'
import { Modal } from "react-bootstrap";
import ToastMessage from '../components/ToastMessage';
import Shimmer from '../features/Shimmer';
export default function Profile() {
    const navigate=useNavigate()
    let[blogs,setBlogs]=useState([])
    let[isDeleting,setIsDeleting]=useState(false)
    let[blogId,setBlogId]=useState("")
    const[showToast,setShowToast]=useState(false)
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const emptyArray=[1,2,3,4,5]
  let userId=localStorage.getItem("userId")  
  useEffect(()=>{
    if(userId==null||userId.length<=0){
        navigate("/signIn")
    }else{
        getUserData()
    }
  },[])  
  async function getUserData(){
   try{
    await fetch(`${host}profileCard?v=${userId}`).then((response)=>response.json()).then((response)=>{
        setBlogs(response.data)
    })
   }catch(e){
    console.log(e);
   }
  }

  async function deleteBlog(){
    setIsDeleting(true)
    try{
        await fetch(`${host}deleteBlog?v=${blogId}`).then((response)=>response.json()).then((response)=>{
            if(response.message==true){
                setIsDeleting(false)
                handleClose()
                getUserData()
            }else{
                setIsDeleting(false)
                setShowToast(!showToast)
                navigate("/profile")
            }
        })
    }catch(e){
        setIsDeleting(false)
        setShowToast(!showToast)
        navigate("/profile")
       }
  }
  return (
    <div className='wrapper'>
        <ToastMessage props={{show:showToast,message:"Could not delete.",closeToast:()=>setShowToast(!showToast)}}/>
        <Modal show={show} onHide={handleClose} centered>
        <Modal.Body className="modalBody">
        {isDeleting&&<div className="loaderContainer">
          <div className="loader"></div>
          </div>}
          <h5>Do want to Delete this blog?</h5>
          <div className="text-end">
          <button className='btn btn-danger' onClick={deleteBlog}>Delete</button>
          <button className='btn bg-transparent text-success ms-3' onClick={handleClose}>Cancel</button>
          </div>
        </Modal.Body>
      </Modal>
        {
         blogs.length>0? blogs.map((index,key)=>{
            return<>
            <BlogCard props={index} key={key}/>
            <span className='deleteBtn' onClick={()=>{
                setBlogId(index.blog_id)
                handleShow()
            }}>[DELETE BLOG]</span>
            </>
          }):emptyArray.map((index,key)=><Shimmer key={key}/>)
        }
    </div>
  )
}
