import React, { useState, useRef, useMemo,useEffect } from "react";
import JoditEditor from "jodit-react";
import { Modal } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import ToastMessage from '../components/ToastMessage';
import host from "../host/host"
export default function WriteBlog() {
  const navigate = useNavigate();

  useEffect(() => {
   if(localStorage.getItem("token")==null){
    navigate("/signIn")
  }else if(localStorage.getItem("token").length==0){
     navigate("/signIn")
   }
  }, [])
  

  function isValidURL(url) {
    const urlRegex = /^(https?|ftp):\/\/[^\s\/$.?#].[^\s]*$/;
    return urlRegex.test(url);
  }
  const editor = useRef(null);
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [show, setShow] = useState(false);
  const [noFill, setNoFill] = useState(false);
  const [isPosting, setIsPosting] = useState(false);
  const[showToast,setShowToast]=useState(false)
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const userId=localStorage.getItem("userId")
 async function publishBlog() {
  if(content!=""&&title!=""&&description!=""&&url!=""&&isValidURL(url)){
    setNoFill(false)
    try{
      setIsPosting(true)
      await fetch(`${host}postBlog`,{
        method:"POST",
        headers:{
          "content-type":"application/json"
        },
        body:JSON.stringify({
          title,url,description,content,userId
        })
      }).then((response)=>response.json()).then((response)=>{
        if(response.message==true){
          setIsPosting(false)
          handleClose()
          navigate("/readBlog")
        }else{
          setIsPosting(false)
          handleClose()

        }
      })
    }catch(e){
      console.log("server error");
    }
  }else{
    setNoFill(true)
  }
  }
  const config = useMemo(()=>{
    return{
      readonly: false, // all options from https://xdsoft.net/jodit/docs/,
    };
  },[])

  return (
    <div className="wrapper">
      <ToastMessage props={{show:showToast,message:"Server Error Occured",closeToast:()=>setShowToast(!showToast)}}/>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton className="border-0">
        </Modal.Header>
        <Modal.Body className="modalBody">
        {isPosting&&<div className="loaderContainer">
          <div className="loader"></div>
          </div>}
          {noFill&&<h6 className="text-danger">Invalid Information (Fill all the fields) And Write A blog.</h6>}
          <input type="text" placeholder="Blog Title"  onChange={(e)=>setTitle(e.target.value)}/>
          <textarea
            name=""
            id=""
            cols="30"
            rows="5"
            placeholder="About Blog"
			onChange={(e)=>setDescription(e.target.value)}
          ></textarea>
          <input
            type="text"
            placeholder="URL of image.."
            onChange={(e) => setUrl(e.target.value)}
          />
          <img src={url} alt="" className="thumbnailImage" />
          <button className="mainBtn my-1" onClick={publishBlog}>Publish</button>
        </Modal.Body>
      </Modal>

      <JoditEditor
        ref={editor}
        value={content}
        config={config}
        tabIndex={1} // tabIndex of textarea
        onBlur={(newContent) => setContent(newContent)} // preferred to use only this option to update the content for performance reasons
        onChange={(newContent) => {}}
      />
      <button onClick={handleShow} className="mainBtn mt-2">
        Publish Blog
      </button>
    </div>
  );
}
