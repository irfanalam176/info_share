import React,{useEffect, useState,useContext} from 'react'
import { Link,useNavigate } from 'react-router-dom'
import host from "../host/host"
import stateContext from '../context/stateContext'
import ToastMessage from '../components/ToastMessage';
export default function SignUp() {
  let{isLogin,setIsLogin}=useContext(stateContext)
  const navigate=useNavigate()
  useEffect(()=>{
    const token=localStorage.getItem("token")
   if(token!=null){
    if(token.length>0){
      navigate("/")
    }
   }
  },[])

  const[showToast,setShowToast]=useState(false)
  let[isSigning,setIsSigning]=useState(false)
  const[error,setError]=useState("")
  const [formData, setFormData] = useState({
    userName: '',
    userEmail: '',
    userPassword: '',
    // Add more fields as needed
  });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const userInfo = {
    userName: formData.userName,
    userEmail: formData.userEmail,
    userPassword: formData.userPassword
};
const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

function isValidEmail(email) {
  return emailRegex.test(email);
}

  async function signUp(e){
    e.preventDefault();
    setIsSigning(true)
    if(userInfo.userEmail!=""&&userInfo.userPassword.length>=8&&isValidEmail(userInfo.userEmail)&&userInfo.userName.length>=3)
    {
      try{
        await fetch(`${host}signUp`,{
          method:"POST",
          headers:{
            "content-type":"application/json"
          },
          body:JSON.stringify(userInfo)
        }).then((response)=>response.json()).then((response)=>{
          if(response.message==true){
            tokenSetter(response)
            setIsSigning(false)
          }
        })
      }catch(e){
        setIsSigning(false)
        setError("Server Error Occured..")
        setShowToast(!showToast)
      }
    }else{
      setIsSigning(false)
      setError("Invalid Information..")
      setShowToast(!showToast)
    }
  }
  function tokenSetter(response){
    if(response.message==true){
      localStorage.setItem("token",JSON.stringify(response.token))
      localStorage.setItem("userId",JSON.stringify(response.userId))
      setIsLogin(true)
      navigate("/writeBlog")
     }
  }
  return (
  <>
    <ToastMessage props={{show:showToast,message:error,closeToast:()=>setShowToast(!showToast)}}/>
   <div className="signWrapper" data-aos="fade-down">
     <div className='signPage'>
      {isSigning&&
      <div className='loaderContainer'>
        <div className="loader"></div>
      </div>
      }
        <h1 className="mainHeading">Sign Up</h1>
        <input type="text" name='userName' placeholder='Name: jhon Doe' onChange={handleInputChange}/>
        <input type="email" name='userEmail' placeholder='jhonDoe@yahoo.com' onChange={handleInputChange}/>
        <input type="password" name='userPassword' placeholder='Enter Your Password (minimum 8 characters)' minLength={8} onChange={handleInputChange}/>
        <div className="text-end  w-100">
        <Link to={"/signIn"}>Already Have Account?</Link>
        </div>
        <button className='mainBtn'onClick={signUp}>Sign Up</button>
    </div>
   </div>
  </>
  )
}
