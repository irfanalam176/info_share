import React,{createContext} from "react"
const stateContext=createContext()
export default stateContext