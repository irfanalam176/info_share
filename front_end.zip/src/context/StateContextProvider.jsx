import React, { useState } from 'react'
import stateContext from './stateContext'
export default function StateContextProvider({children}) {
  let[isLogin,setIsLogin]=useState(false)  
  let[search,setSearch]=useState("")  
  return (
    <stateContext.Provider value={{isLogin,setIsLogin,search,setSearch}}>
        {children}
    </stateContext.Provider>
  )
}
