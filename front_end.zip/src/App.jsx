import React from 'react'
import NavBar from './features/NavBar'
import Home from './pages/Home'
import { Route, Routes } from 'react-router-dom'
import WriteBlog from './pages/WriteBlog'
import ReadBlog from './pages/ReadBlog'
import SignIn from './pages/SignIn'
import SignUp from './pages/SignUp'
import StateContextProvider from './context/StateContextProvider'
import BlogPage from './pages/BlogPage'
import Profile from './pages/Profile'
import Search from './pages/Search'

export default function App() {
  return (
    <StateContextProvider>
      <NavBar/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/writeBlog' element={<WriteBlog/>}/>
        <Route path='/readBlog' element={<ReadBlog/>}/>
        <Route path='/readBlog/search' element={<Search/>}/>
        <Route path='/signUp' element={<SignUp/>}/>
        <Route path='/signIn' element={<SignIn/>}/>
        <Route path='/readBlog/blogPage' element={<BlogPage/>}/>
        <Route path='/profile' element={<Profile/>}/>
      </Routes> 
    </StateContextProvider>
  )
}
