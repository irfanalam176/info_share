import React from 'react'

export default function Shimmer() {
  return (
    <div className='shimmer'>
        <div className="shimmerImage"></div>
        <div className='my-auto'>
            <div className="shimmerText"></div>
            <div className="shimmerText"></div>
            <div className="shimmerText"></div>
        </div>
    </div>
  )
}
