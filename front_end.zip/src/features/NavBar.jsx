import React,{useEffect,useContext} from 'react'
import {Link,  NavLink,useNavigate } from 'react-router-dom'
import stateContext from '../context/stateContext'
import { Dropdown } from 'react-bootstrap'
import profile from  "../assets/profile.png"
import menu from  "../assets/menu.png"
export default function NavBar() {
  const navigate=useNavigate()
  let{isLogin,setIsLogin}=useContext(stateContext)
  useEffect(()=>{
    const token =localStorage.getItem("token")
    if(token!=null){
      if(token.length>0){
        setIsLogin(true)
      }
    }
  },[])
  function logout(){
    localStorage.removeItem("token")
    localStorage.removeItem("userId")
    setIsLogin(false)
      navigate("/")
  }

  document.querySelectorAll(".links a").forEach((el)=>{
    el.addEventListener("click",()=>{
      document.querySelector(".links").classList.remove("show")
    })
  })
  return (
    <div className='navBar'>
        <span className='menuBtn' onClick={()=>{
          document.querySelector(".links").classList.toggle("show")
        }}><img src={menu} alt="" /></span>
        <h1 className='logo'><span>INF</span>SHARE</h1>
        <div className="links">
            <NavLink to="/">Home</NavLink>
            <NavLink to="/readBlog">Read Blogs</NavLink>
            <Link to="/writeBlog" className='mainBtn'>Write Blog</Link>
        </div>
            {isLogin&&
              <Dropdown>
                  <Dropdown.Toggle variant="success" id="dropdown-basic">
                    <img src={profile} alt="" />
                  </Dropdown.Toggle>
            
                  <Dropdown.Menu>
                    <Dropdown.Item onClick={()=>navigate("/profile")}>
                     Profile
                    </Dropdown.Item>
                    <Dropdown.Item onClick={logout}>Log Out</Dropdown.Item>
                  </Dropdown.Menu>
              </Dropdown>
            }
    </div>
  )
}
