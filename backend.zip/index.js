const express = require('express');
const cors=require("cors")
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const db = require("./model/db")
const app = express();
const secretKey="asdfasdfa0980983453vvvee0022NNNN"
const PORT = process.env.PORT || 3000;
app.use(express.json())
app.use(cors())
app.post("/signUp",async(req,res)=>{
    const{userName,userEmail,userPassword}=req.body
    const uuid =  uuidv4();
    const sql="CALL signUp(?,?,?,?)"
    const incryptPassword= await bcrypt.hash(userPassword,10)
    db.query(sql,[uuid,userName,userEmail,incryptPassword],(err,resp)=>{
       if(err){
        if(err.code=="ER_DUP_ENTRY"){
            res.json({message:"User Already Exist"})
        }
       }
        else{
            const token = jwt.sign({ userEmail }, secretKey, { expiresIn: '30d' });
            res.json({message:true,token:token,userId:uuid})
        }
    })
})

app.post("/signIn",(req,res)=>{
    const{userEmail,userPassword}=req.body
    const sql="CALL signIn(?)"
    db.query(sql,[userEmail],async(err,resp)=>{
        if(err) throw err
        else{
            if(resp[0].length==0){
                res.json({message:false})
            }else{ 
               const decryptPassword = await bcrypt.compare(userPassword,resp[0][0].password)
                const token = jwt.sign({ userEmail }, secretKey, { expiresIn: '30d' });
               if(decryptPassword==true){
                res.json({message:true,token:token,userId:resp[0][0].user_id})
            }else{
                   res.json({message:false})
               }
            }
        }
    })
})


app.post("/postBlog",(req,res)=>{
    const{title,url,description,content,userId}=req.body
    const uuid =  uuidv4();
    const sql="CALL postBlog(?,?,?,?,?,?)"
    db.query(sql,[uuid,title,url,description.toLocaleLowerCase(),content,userId.slice(1,-1)],(err,resp)=>{
        if(err) {
            res.json({message:false})
        }
        else{
            res.json({message:true})
        }
    })
})

app.get("/blogCard",(req,res)=>{
    const sql ="CALL blogCard()"
    db.query(sql,(err,resp)=>{
        if(err) throw err
        else{
            res.json({message:true,data:resp[0]})
        }
    })
})

app.get("/readBlog", (req, res) => {
    const sql = "CALL readBlog(?)";
    let { q, v } = req.query;
    let response = {
        html: '',
        userName: ''
    };

    db.query(sql, [q], (err, resp) => {
        if (err) throw err;
        else {
            response.html = resp[0][0].blog;

            db.query("CALL userSelection(?)",[v], (err, resp) => {
                if (err) throw err;
                else {
                    response.userName = resp[0][0].user_name;
                    res.json({ result: response });
                }
            });
        }
    });
});


app.get("/profileCard",(req,res)=>{
    const{v}=req.query
    const sql ="CALL profileCard(?)"
    db.query(sql,[v.slice(1,-1)],(err,resp)=>{
        if(err) throw err
        else{
            res.json({message:true,data:resp[0]})
        }
    })
})

app.get("/deleteBlog",(req,res)=>{
    const{v}=req.query
    const sql="CALL deletBlog(?)"
    db.query(sql,[v],(err,resp)=>{
        if(err){
            res.json({message:false})
        }else{
            res.json({message:true})
        }
    })
})


app.get("/searchBlog",(req,res)=>{
    const{v}=req.query
    const sql ="CALL searchBlog(?)"
    db.query(sql,[v.toLocaleLowerCase()],(err,resp)=>{
        if(err) throw err
        else{
            res.json({message:true,data:resp[0]})
        }
    })
})
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});